import firebase from "firebase";

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAqw_aZe4DW-pXglzIY3S60ZSs4PkWknCo",
  authDomain: "project-8546022775006574941.firebaseapp.com",
  projectId: "project-8546022775006574941",
  storageBucket: "project-8546022775006574941.firebasestorage.app",
  messagingSenderId: "427782535881",
  appId: "1:427782535881:web:cf23c58f1b857d77c66b18",
  measurementId: "G-TK3LEQLCMZ"
};

if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export const database = firebase.firestore()
export const auth = firebase.auth()